//
//  TableViewController.swift
//  TableView
//
//  Created by Aman Gill on 2022-08-06.
//

import Foundation
var name: String = ""
func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "doneSegue" {
        name = movieName.text!
    }
}
