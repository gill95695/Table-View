//
//  ViewController.swift
//  TableView
//
//  Created by Aman Gill on 2022-08-05.
//
import UIKit
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // Data model: These strings will be the data for the table view cells
    let movie: [String] = ["Eternals", "Dune", "No Time To Die", "Last Night  Soho", "Halloween Kills"]
    
    // cell reuse id (cells that scroll out of view can be reused)
        let cellReuseIdentifier = "cell"
        
        // don't forget to hook this up from the storyboard
        @IBOutlet var tableView: UITableView!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Register the table view cell class and its reuse id
            self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
            
            // (optional) it remove the extra empty cell divider lines
            // self.tableView.tableFooterView = UIView()

            // This view controller itself will provide the delegate methods and row data for the table view.
            tableView.delegate = self
            tableView.dataSource = self
        }
        
        // number of rows in table view
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return self.movie.count
        }
        
        // create a cell for each table view row
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            // create a new cell if needed or reuse an old one
            let cell:UITableViewCell = self.tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier) as UITableViewCell!
            
            // set the text from the data model
            cell.textLabel?.text = self.movie[indexPath.row]
            
            return cell
        }
        
        // method to run when table view cell is tapped
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            print("You tapped cell number \(indexPath.row).")
        }
        // this method handles row deletion
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {

            if editingStyle == .delete {

                // remove the item from the data model
                movie.remove(at: indexPath.row)

                // delete the table view row
                tableView.deleteRows(at: [indexPath], with: .fade)

            }
        }
        // this method handles move rows
        func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
            let movedObject = self.movie[sourceIndexPath.row]
            movie.remove(at: sourceIndexPath.row)
            movie.insert(movedObject, at: destinationIndexPath.row)
        }
        @IBAction func cancel(segue:UIStoryboardSegue) {
      
        }

        @IBAction func done(segue:UIStoryboardSegue) {
         
        }
        
        @IBAction func done(segue:UIStoryboardSegue) {
        let movieDetailVC = segue.source as! addMovie
        newmovie = movieDetailVC.name
           
        movie.append(newmovie)
        tableView.reloadData()
    }
    }
